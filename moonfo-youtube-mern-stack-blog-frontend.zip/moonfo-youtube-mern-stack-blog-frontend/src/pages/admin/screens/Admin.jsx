const Admin = () => {
  return <div>Admin dashboard</div>;
};

export default Admin;
